﻿using System.ComponentModel.DataAnnotations;

namespace ContactInformation.Models

{
    public class ContactMetadata
    {
        [StringLength(50)]
        [Required(ErrorMessage = "First Name is required")]
        [Display(Name = "First Name")]
        public string FirstName;
        [StringLength(50)]
        [Required(ErrorMessage = "Last Name is required")]
        [Display(Name = "Last Name")]
        public string LastName;
        [StringLength(50)]
        [Required(ErrorMessage = "Enter your e-mail address")]
        [Display(Name = "Email")]
        public string Email;
        [StringLength(12)]
        [Required(ErrorMessage = "Enter your Phone Number")]
        [Display(Name = "Phone Number")]
        public string PhoneNumber;
        [Display(Name = "Active")]
        public bool Status;
    }

    [MetadataType(typeof(ContactMetadata))]
    public partial class Contact
    {
    }
}