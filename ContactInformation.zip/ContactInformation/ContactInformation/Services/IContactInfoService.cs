﻿using System.Collections.Generic;
using ContactInformation.Models;

namespace ContactInformation.Services
{
    public interface IContactInfoService
    {
        bool CreateContact(Contact contactToCreate);
        bool DeleteContact(Contact contactToDelete);
        bool EditContact(Contact contactToEdit);
        Contact GetContact(int id);
        IEnumerable<Contact> ListContacts();
    }
}
