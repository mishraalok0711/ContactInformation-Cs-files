﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using ContactInformation.ExceptionLogging;
using ContactInformation.Models;
using ContactInformation.Models.Validation;
using ContactInformation.Services;

namespace ContactInformation.Controllers
{
    public class ContactController : Controller
    {
        private IContactInfoService contactInfoService;

        public ContactController()
        {
            contactInfoService = new ContactInfoService(new ModelStateValidation(this.ModelState));
        }

        public ContactController(IContactInfoService service)
        {
            contactInfoService = service;
        }

        [ExceptionHandler]
        public ActionResult ContactList()
        {
            return View(contactInfoService.ListContacts());
        }

        [ExceptionHandler]
        public ActionResult Create()
        {
            return View("Contact");
        }

        [ExceptionHandler]
        [AcceptVerbs(HttpVerbs.Post)]
        public ActionResult Create([Bind(Exclude = "Id")] Contact createContact)
        {
            if (contactInfoService.CreateContact(createContact))
            {
                return RedirectToAction("ContactList");
            }
            else
            {
                return View("Contact");
            }

        }

        [ExceptionHandler]
        public ActionResult Edit(int id)
        {
            return View(contactInfoService.GetContact(id));
        }

        [ExceptionHandler]
        [AcceptVerbs(HttpVerbs.Post)]
        public ActionResult Edit(Contact editContact)
        {
            if (contactInfoService.EditContact(editContact))
                return RedirectToAction("ContactList");
            return View();
        }

        [ExceptionHandler]
        public ActionResult Delete(int id)
        {
            return View(contactInfoService.GetContact(id));
        }

        [ExceptionHandler]
        [AcceptVerbs(HttpVerbs.Post)]
        public ActionResult Delete(Contact deleteContact)
        {
            if (contactInfoService.DeleteContact(deleteContact))
                return RedirectToAction("ContactList");
            return View();
        }

        [ExceptionHandler]
        public ActionResult Details(int id)
        {
            return View(contactInfoService.GetContact(id));
        }
    }
}