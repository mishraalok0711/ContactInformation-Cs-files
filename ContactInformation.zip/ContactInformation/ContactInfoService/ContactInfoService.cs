﻿using System;
using System.Collections.Generic;
using ContactInformation.Models;
using ContactInformation.Interfaces;
using System.Text.RegularExpressions;

namespace ContactInfoService
{
    public class ContactInfoService : IContactInfoService
    {
        private IValidation validation;
        private IContactInfoRepository contactInfoRepository;


        public ContactInfoService(IValidation validation)
            : this(validation, new ContactInfoRepository())
        {

        }


        public ContactInfoService(IValidation objValidation, IContactInfoRepository objContactInfoRepository)
        {
            validation = objValidation;
            contactInfoRepository = objContactInfoRepository;
        }


        public bool ValidateContact(Contact contactToValidate)
        {
            if (contactToValidate.FirstName.Trim().Length == 0)
                validation.AddError("FirstName", "First name is required.");
            if (contactToValidate.LastName.Trim().Length == 0)
                validation.AddError("LastName", "Last name is required.");
            if (contactToValidate.PhoneNumber.Length > 0 && !Regex.IsMatch(contactToValidate.PhoneNumber, @"((\(\d{3}\) ?)|(\d{3}-))?\d{3}-\d{4}"))
                validation.AddError("PhoneNumber", "Invalid phone number.");
            if (contactToValidate.Email.Length > 0 && !Regex.IsMatch(contactToValidate.Email, @"^[\w-\.]+@([\w-]+\.)+[\w-]{2,4}$"))
                validation.AddError("Email", "Invalid email address.");
            return validation.IsValid;
        }


        public bool CreateContact(Contact contactToCreate)
        {
            if (!ValidateContact(contactToCreate))
                return false;
            try
            {
                contactInfoRepository.CreateContact(contactToCreate);
            }
            catch (Exception ex)
            {
                return false;
            }
            return true;
        }

        public bool EditContact(Contact contactToEdit)
        {
            if (!ValidateContact(contactToEdit))
                return false;
            try
            {
                contactInfoRepository.EditContact(contactToEdit);
            }
            catch (Exception ex)
            {
                return false;
            }
            return true;
        }

        public bool DeleteContact(Contact contactToDelete)
        {
            try
            {
                contactInfoRepository.DeleteContact(contactToDelete);
            }
            catch (Exception ex)
            {
                return false;
            }
            return true;
        }

        public Contact GetContact(int id)
        {
            return contactInfoRepository.GetContact(id);
        }

        public IEnumerable<Contact> ListContacts()
        {
            return contactInfoRepository.ListContacts();
        }

    }
}