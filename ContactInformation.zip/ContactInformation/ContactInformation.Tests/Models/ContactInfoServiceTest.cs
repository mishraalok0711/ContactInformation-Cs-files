﻿using System;
using System.Web.Mvc;
using ContactInformation.Interfaces;
using ContactInformation.Models;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using ContactInformation.Models.Validation;
using ContactInformation.Services;

namespace ContactInformation.Tests.Models
{
    [TestClass]
    public class ContactInfoServiceTest
    {
        private Mock<IContactInfoRepository> contactMockRepository;
        private ModelStateDictionary modelState;
        private IContactInfoService contactInfoService;

        [TestInitialize]
        public void Initialize()
        {
            contactMockRepository = new Mock<IContactInfoRepository>();
            modelState = new ModelStateDictionary();
            contactInfoService = new ContactInfoService(new ModelStateValidation(modelState), contactMockRepository.Object);
        }

        [TestMethod]
        public void CreateContact()
        {
            // Arrange
            var contact = Contact.CreateContact(-1, "Alok", "Mishra", "alokmishra@test.com", "1234567891", true);

            // Act
            var result = contactInfoService.CreateContact(contact);
        
            // Assert
            Assert.IsTrue(result);
        }


        [TestMethod]
        public void CreateContactRequiredFirstName()
        {
            // Arrange
            var contact = Contact.CreateContact(-1, string.Empty, "Mishra", "alokmishra@test.com", "1234567891", true);

            // Act
            var result = contactInfoService.CreateContact(contact);

            // Assert
            Assert.IsFalse(result);
            var error = modelState["FirstName"].Errors[0];
            Assert.AreEqual("First name is required.", error.ErrorMessage);
        }


        [TestMethod]
        public void CreateContactRequiredLastName()
        {
            // Arrange
            var contact = Contact.CreateContact(-1, "Alok", string.Empty, "alokmishra@test.com", "1234567891", true);

            // Act
            var result = contactInfoService.CreateContact(contact);

            // Assert
            Assert.IsFalse(result);
            var error = modelState["LastName"].Errors[0];
            Assert.AreEqual("Last name is required.", error.ErrorMessage);
        }

        [TestMethod]
        public void CreateContactInvalidPhone()
        {
            // Arrange
            var contact = Contact.CreateContact(-1, "Alok", "Mishra", "alokmishra@test.com", "55445", true);

            // Act
            var result = contactInfoService.CreateContact(contact);

            // Assert
            Assert.IsFalse(result);
            var error = modelState["PhoneNumber"].Errors[0];
            Assert.AreEqual("Invalid phone number. Minimum 10 digits", error.ErrorMessage);
        }


        [TestMethod]
        public void CreateContactInvalidEmail()
        {
            // Arrange
            var contact = Contact.CreateContact(-1, "Alok", "Mishra", "5com", "1234567891", true);

            // Act
            var result = contactInfoService.CreateContact(contact);

            // Assert
            Assert.IsFalse(result);
            var error = modelState["Email"].Errors[0];
            Assert.AreEqual("Invalid email address.", error.ErrorMessage);
        }
    }
}
